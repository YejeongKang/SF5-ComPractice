#pragma once

#include <string>
#include <vector>
#include <iostream>

using namespace std;

vector <int> userInput(int n1, int n2);