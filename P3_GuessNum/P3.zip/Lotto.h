#pragma once

#include <string>
#include <vector>

using namespace std;

vector <int> generateLottoNum(int n1, int n2);

int CompareVec(vector<int> vec1, vector <int> vec2, int r);